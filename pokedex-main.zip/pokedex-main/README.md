# Pokédex con PokéAPI

#### Aquí podrán encontrar los archivos que utilicé en este video.

El video está en YouTube, [haciendo clic aquí](https://youtu.be/EmxvMPcIy5c).

### Autor
- Carpi Coder

### Contacto
- [www.carpicoder.com](https://carpicoder.com)
- [hola@carpicoder.com](mailto:hola@carpicoder.com)

### Redes sociales
- [YouTube](https://youtube.com/carpicoder)
- [Instagram](https://instagram.com/carpicoder)
- [Twitter](https://twitter.com/carpicoder)

### Para apoyar mi contenido, podés

- [Invitarme un Cafecito](https://cafecito.com/carpicoder)